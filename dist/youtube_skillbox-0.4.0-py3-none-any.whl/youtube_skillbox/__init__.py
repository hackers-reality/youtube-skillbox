"""
YouTube Skillbox package.
"""