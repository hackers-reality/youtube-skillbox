with open('skills/youtube/scripts/ytdata.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()
for i, line in enumerate(lines, 1):
    if '"views"' in line and 'sig[' in line:
        print(f'{i}: {line.rstrip()}')
    if '"authority"' in line and 'sig[' in line:
        print(f'{i}: {line.rstrip()}')
    if '"titles"' in line and 'sig[' in line:
        print(f'{i}: {line.strip()}')
    if 'sig["entrenchment"]' in line:
        print(f'{i}: {line.rstrip()}')
    if 'sig["velocity"]' in line:
        print(f'{i}: {line.rstrip()}')