import re

with open(r"E:\youtube-skillbox\skills\youtube\scripts\ytdata.py", "r", encoding="utf-8") as f:
    content = f.read()

with open(r"E:\youtube-skillbox\tmp\trends_insert.py", "r", encoding="utf-8") as f:
    insert = f.read()

# Find the marker and replace
marker = '''for r in rows:
        flags = ("  Y" if r["year_trend"] else "") + ("  Q" if r["question"] else "")
        print(f"{r['score']:>5}  {r['yt']:>3}  {r['ddg']:>3}  #{r['best_pos']:<3} "
              f"{r['keyword']}{flags}")


# ---- Rank tracking: where a video sits for a keyword (no API key) ----'''

if marker in content:
    content = content.replace(marker, insert)
    with open(r"E:\youtube-skillbox\skills\youtube\scripts\ytdata.py", "w", encoding="utf-8") as f:
        f.write(content)
    print("Replaced successfully")
else:
    print("Marker not found - trying flexible match")
    # Try with flexible whitespace
    pattern = re.compile(r'for r in rows:.*?# ---- Rank tracking: where a video sits for a keyword \(no API key\) ----', re.DOTALL)
    if pattern.search(content):
        content = pattern.sub(insert, content)
        with open(r"E:\youtube-skillbox\skills\youtube\scripts\ytdata.py", "w", encoding="utf-8") as f:
            f.write(content)
        print("Replaced with regex")
    else:
        print("Still not found")