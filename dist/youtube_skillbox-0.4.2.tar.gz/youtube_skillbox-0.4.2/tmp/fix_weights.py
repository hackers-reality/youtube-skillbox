with open('skills/youtube/scripts/ytdata.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix views weight from 40 to 35 (total should be 100: 35+25+20+15+10=100)
content = content.replace('sig["views"] = (40, v, f"median {fmt_views(int(med))} views")',
                          'sig["views"] = (35, v, f"median {fmt_views(int(med))} views")')

with open('skills/youtube/scripts/ytdata.py', 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed views weight from 40 to 35. New total: 35+25+20+15+10 = 100%")