import subprocess
import json

proc = subprocess.run(['python', '-m', 'yt_dlp', '--skip-download', '--dump-single-json', 'https://www.youtube.com/@UnscriptedMoments'], capture_output=True, text=True, timeout=30)
d = json.loads(proc.stdout)
print('Profile subs:', d.get('channel_follower_count'))

proc2 = subprocess.run(['python', '-m', 'yt_dlp', '--skip-download', '--flat-playlist', '--dump-json', 'https://www.youtube.com/@UnscriptedMoments/videos', '--playlist-end', '1'], capture_output=True, text=True, timeout=30)
for line in proc2.stdout.strip().splitlines():
    if line.startswith('{'):
        pv = json.loads(line)
        print('Video ID:', pv.get('id'))
        proc3 = subprocess.run(['python', '-m', 'yt_dlp', '--skip-download', '--dump-single-json', 'https://www.youtube.com/watch?v=' + pv.get('id')], capture_output=True, text=True, timeout=30)
        vd = json.loads(proc3.stdout)
        print('Video subs:', vd.get('channel_follower_count'))
        break