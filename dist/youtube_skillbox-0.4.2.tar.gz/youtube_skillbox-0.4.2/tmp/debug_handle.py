import urllib.request
import re
import json

url = 'https://www.youtube.com/@UnscriptedMoments'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'replace')

# Extract ytInitialData
for pat in (r'var ytInitialData\s*=\s*(\{.*?\});</script>',
            r'window\["ytInitialData"\]\s*=\s*(\{.*?\});',
            r'ytInitialData\s*=\s*(\{.*?\});'):
    m = re.search(pat, html, re.S)
    if m:
        data = json.loads(m.group(1))
        print('Found ytInitialData')
        break

# Search for channelId
def find_all(obj, key, path=''):
    if isinstance(obj, dict):
        if key in obj:
            print(f'Found {key} at {path}: {obj[key]}')
        for k, v in obj.items():
            find_all(v, key, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            find_all(v, key, f'{path}[{i}]')

find_all(data, 'channelId')
find_all(data, 'browseId')