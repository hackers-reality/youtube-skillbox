import os

skills_dir = r"E:\youtube-skillbox\skills"
prereq_text = """## Prerequisites

`yt-dlp` installed: `python -m pip install --user -U yt-dlp`. Uses the shared data module at `../youtube/scripts/ytdata.py` (relative to this SKILL.md). **Ensure `youtube/scripts/ytdata.py` exists alongside this skill** (copy `scripts/` when installing).

"""

for skill_dir in [
    "yt-chapters", "yt-comment", "yt-edit", "yt-package", 
    "yt-plan", "yt-retention", "yt-script", "yt-shorts", "yt-viral"
]:
    skill_path = os.path.join(skills_dir, skill_dir, "SKILL.md")
    if os.path.exists(skill_path):
        with open(skill_path, 'r', encoding='utf-8') as f:
            content = f.read()
        if '## Prerequisites' not in content:
            # Insert after the first heading
            content = content.replace('# ', '# \n\n## Prerequisites\n\n`yt-dlp` installed: `python -m pip install --user -U yt-dlp`. Uses the shared data module at `../youtube/scripts/ytdata.py` (relative to this SKILL.md). **Ensure `youtube/scripts/ytdata.py` exists alongside this skill** (copy `scripts/` when installing).\n\n# ', 1)
            with open(skill_path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Updated: {skill_dir}")
        else:
            print(f"Already has prerequisites: {skill_dir}")