with open(r"E:\youtube-skillbox\skills\yt-audit\SKILL.md", 'r', encoding='utf-8') as f:
    content = f.read()

# Fix the inputs line
content = content.replace(
    'ALL previous phases: youtube, transcript, yt-script, yt-package, yt-seo, yt-viral, yt-retention',
    'ALL previous phases: youtube, transcript, yt-script, yt-package, yt-seo, yt-viral, yt-retention (optional)'
)

# Add the agent behavior note after the frontmatter
if 'Agent behavior' not in content:
    content = content.replace(
        'An audit that lists twenty problems is a way of avoiding the one that matters. This ends in ONE fix.',
        'An audit that lists twenty problems is a way of avoiding the one that matters. This ends in ONE fix.\n\n**Agent behavior**: If yt-retention data is missing, note in audit: *"Retention analysis skipped — no Studio CSV provided. For pacing fixes, export Studio → Analytics → Engagement → Audience Retention → Download CSV and re-run."*'
    )

with open(r"E:\youtube-skillbox\skills\yt-audit\SKILL.md", 'w', encoding='utf-8') as f:
    f.write(content)

print("Done!")