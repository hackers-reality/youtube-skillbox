import urllib.request
import re
import json

url = 'https://www.youtube.com/channel/UC7YGYCm-n48Xea43wEqUDRg'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'replace')

# Extract ytcfg
m = re.search(r'ytcfg\.set\((\{.*?\})\);', html, re.S)
if m:
    cfg = json.loads(m.group(1))
    key = cfg.get('INNERTUBE_API_KEY')
    ctx = cfg.get('INNERTUBE_CONTEXT')

if key and ctx:
    browse_id = 'UC7YGYCm-n48Xea43wEqUDRg'
    
    payload = json.dumps({"context": ctx, "browseId": browse_id}).encode('utf-8')
    api_url = f"https://www.youtube.com/youtubei/v1/browse?key={key}"
    headers = {'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json'}
    req2 = urllib.request.Request(api_url, data=payload, headers=headers, method='POST')
    resp = json.loads(urllib.request.urlopen(req2, timeout=30).read().decode('utf-8', 'replace'))
    
    # Save response to file for inspection
    with open('tmp/browse_resp.json', 'w', encoding='utf-8') as f:
        json.dump(resp, f, ensure_ascii=False, indent=2)
    
    print('Response saved. Keys at root:', list(resp.keys()))
    
    # Check metadata
    meta = resp.get('metadata', {})
    print('Metadata keys:', list(meta.keys()))
    if 'channelMetadataRenderer' in meta:
        print('Channel meta:', meta['channelMetadataRenderer'])
    
    # Check header
    header = resp.get('header', {})
    print('Header keys:', list(header.keys()))