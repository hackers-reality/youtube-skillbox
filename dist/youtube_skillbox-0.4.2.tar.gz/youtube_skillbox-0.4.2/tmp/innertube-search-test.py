"""Does Innertube search honor client.gl / client.hl? (gap-fill feasibility test)"""
import json
import re
import sys
import urllib.request

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
      "Accept-Language": "en-US,en;q=0.9",
      "Content-Type": "application/json"}


def get_cfg():
    req = urllib.request.Request("https://www.youtube.com/", headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        html = r.read().decode("utf-8", "replace")
    m = re.search(r"ytcfg\.set\((\{.*?\})\);", html, re.S)
    cfg = json.loads(m.group(1))
    return cfg["INNERTUBE_API_KEY"], cfg["INNERTUBE_CONTEXT"]


def search(key, ctx, query, gl, hl, limit=5):
    ctx = json.loads(json.dumps(ctx))          # deep copy
    ctx["client"]["gl"] = gl
    ctx["client"]["hl"] = hl
    payload = json.dumps({"context": ctx, "query": query}).encode()
    url = f"https://www.youtube.com/youtubei/v1/search?key={key}"
    req = urllib.request.Request(url, data=payload, headers=UA, method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))

    out = []

    def walk(o):
        if isinstance(o, dict):
            if "videoRenderer" in o:
                v = o["videoRenderer"]
                vid = v.get("videoId", "?")
                title = "".join(t.get("text", "") for t in v.get("title", {}).get("runs", []))
                out.append((vid, title))
            for x in o.values():
                walk(x)
        elif isinstance(o, list):
            for x in o:
                walk(x)

    walk(data)
    seen, uniq = set(), []
    for vid, title in out:
        if vid not in seen:
            seen.add(vid)
            uniq.append((vid, title))
    return uniq[:limit]


key, base = get_cfg()
print(f"api key: {key[:12]}...  client: {base['client'].get('clientName')}")
print(f"default gl in context: {base['client'].get('gl')}  hl: {base['client'].get('hl')}\n")

q = "how to grow youtube"
sets = {}
for gl, hl in (("US", "en"), ("IN", "hi"), ("JP", "ja")):
    res = search(key, base, q, gl, hl)
    sets[gl] = [vid for vid, _ in res]
    print(f"--- gl={gl} hl={hl} ---")
    for i, (vid, title) in enumerate(res, 1):
        print(f"  {i}. {title[:70]}  [{vid}]")
    print()

print("=== overlap check (same video IDs across regions?) ===")
for gl, ids in sets.items():
    print(f"  gl={gl}: {ids}")
print(f"\nUS vs IN identical top5: {sets['US'] == sets['IN']}")
print(f"US vs JP identical top5: {sets['US'] == sets['JP']}")
