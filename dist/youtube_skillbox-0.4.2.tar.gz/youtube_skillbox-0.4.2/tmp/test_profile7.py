import json

with open('tmp/browse_resp.json', 'r', encoding='utf-8') as f:
    resp = json.load(f)

# Check header content
header = resp.get('header', {})
page_header = header.get('pageHeaderRenderer', {})
content = page_header.get('content', {})
page_header_vm = content.get('pageHeaderViewModel', {})
print('pageHeaderViewModel keys:', list(page_header_vm.keys()))

def find_all(obj, key, path=''):
    if isinstance(obj, dict):
        if key in obj:
            print(f'Found {key} at {path}: {obj[key]}')
        for k, v in obj.items():
            find_all(v, key, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            find_all(v, key, f'{path}[{i}]')

find_all(page_header_vm, 'subscriber')
find_all(page_header_vm, 'follower')
find_all(page_header_vm, 'metadata')