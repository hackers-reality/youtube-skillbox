import urllib.request
import re
import json

url = 'https://www.youtube.com/@Moments_Unscriptedorignal'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'replace')

# Extract ytInitialData
for pat in (r'var ytInitialData\s*=\s*(\{.*?\});</script>',
            r'window\["ytInitialData"\]\s*=\s*(\{.*?\});',
            r'ytInitialData\s*=\s*(\{.*?\});'):
    m = re.search(pat, html, re.S)
    if m:
        data = json.loads(m.group(1))
        print('Found ytInitialData')
        break

# Look at the structure
def find_all_channel_ids(obj, path=''):
    if isinstance(obj, dict):
        if "channelId" in obj and isinstance(obj["channelId"], str) and obj["channelId"].startswith("UC"):
            print(f'Found channelId at {path}: {obj["channelId"]}')
            # Print context
            print(f'  Keys around it: {list(obj.keys())[:10]}')
        for k, v in obj.items():
            find_all_channel_ids(v, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            find_all_channel_ids(v, f'{path}[{i}]')

find_all_channel_ids(data)

# Also check metadata
meta = data.get('metadata', {})
print('\nMetadata keys:', list(meta.keys()))
if 'channelMetadataRenderer' in meta:
    print('Channel metadata:', meta['channelMetadataRenderer'])