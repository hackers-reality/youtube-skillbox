import re
import os

files = [
    'skills/youtube/SKILL.md',
    'skills/transcript/SKILL.md',
    'skills/yt-audit/SKILL.md',
    'skills/yt-seo/SKILL.md',
    'skills/yt-script/SKILL.md',
    'skills/yt-package/SKILL.md',
    'skills/yt-plan/SKILL.md',
    'skills/yt-retention/SKILL.md',
    'skills/yt-viral/SKILL.md',
    'skills/yt-comment/SKILL.md',
    'skills/yt-chapters/SKILL.md',
]
valid = {'search','channel','latest','playlist','profile','posts','sections','shows','home','info','scorecard','outliers','gap','keywords','compete','trends','track'}
for f in files:
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            content = fh.read()
        found = re.findall(r'`([^`]+)`', content)
        invalid = [m for m in found if m not in valid and m not in ['ytdata.py', 'ytdata']]
        if invalid:
            print(f'{f}: {invalid}')
        else:
            print(f'{f}: OK')
    except Exception as e:
        print(f'{f}: ERROR - {e}')