with open("skills/youtube/scripts/ytdata.py", "r", encoding="utf-8") as f:
    content = f.read()
print('audit subparser present:', 'add_parser("audit"' in content)
print('compete subparser present:', 'add_parser("compete"' in content)
print('track subparser present:', 'add_parser("track"' in content)
