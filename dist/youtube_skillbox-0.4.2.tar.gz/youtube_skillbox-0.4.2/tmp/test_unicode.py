import unicodedata
for ch in 'ютуб':
    print(ch, unicodedata.name(ch, '').split()[0])
for ch in 'ユーチューブ':
    print(ch, unicodedata.name(ch, '').split()[0])