import json

with open('tmp/browse_resp.json', 'r', encoding='utf-8') as f:
    resp = json.load(f)

# Check header
header = resp.get('header', {})
page_header = header.get('pageHeaderRenderer', {})
print('pageHeaderRenderer keys:', list(page_header.keys()))

# Check for subscriber count in header
def find_all(obj, key, path=''):
    if isinstance(obj, dict):
        if key in obj:
            print(f'Found {key} at {path}: {obj[key]}')
        for k, v in obj.items():
            find_all(v, key, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            find_all(v, key, f'{path}[{i}]')

find_all(page_header, 'subscriberCount')
find_all(page_header, 'subscriber')
find_all(page_header, 'follower')

# Check contents
contents = resp.get('contents', {})
find_all(contents, 'subscriberCount')
find_all(contents, 'subscriber')
find_all(contents, 'follower')