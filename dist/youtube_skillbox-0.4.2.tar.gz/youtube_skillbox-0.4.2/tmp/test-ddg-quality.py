"""Quality checks: DDG kl mapping, live DDG, graceful degradation when DDG is down."""
import sys
import types

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

print("=== 1. gl/hl -> DDG kl mapping ===")
for gl, hl in (("US", "en"), ("GB", "en"), ("IN", "hi"), ("IN", "en"),
               ("JP", "ja"), ("DE", "de"), ("FR", "fr"), ("XX", "en"),
               ("BR", "pt"), ("AU", "en")):
    print(f"  gl={gl} hl={hl}  ->  kl={ytdata._ddg_kl(gl, hl)}")

print("\n=== 2. live DDG lookup ===")
for s in ytdata._suggest_ddg("how to grow youtube", kl="us-en")[:5]:
    print(f"  - {s}")

print("\n=== 3. DDG returns nothing (rate-limited / down) -> must still work ===")
ytdata._suggest_ddg = lambda *a, **k: []
a = types.SimpleNamespace(seed="youtube seo", letters="", patterns=True, limit=5,
                          gl="US", hl="en", sources="yt,ddg", json=False)
ytdata.cmd_keywords(a)

print("\n=== 4. BOTH engines down -> must fail loudly, not silently ===")
ytdata._suggest = lambda *a, **k: []
try:
    ytdata.cmd_keywords(a)
    print("  BAD: exited without error")
except SystemExit as e:
    print(f"  GOOD: SystemExit({e.code})")
