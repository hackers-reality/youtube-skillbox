"""Probe DuckDuckGo autocomplete: response format, locale (kl) support, limits."""
import json
import sys
import urllib.parse
import urllib.request

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
      "Accept": "application/json, text/javascript, */*; q=0.01"}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", "replace")


q = urllib.parse.quote("how to make paneer")
tests = [
    ("bare",            f"https://duckduckgo.com/ac/?q={q}"),
    ("type=list",       f"https://duckduckgo.com/ac/?q={q}&type=list"),
    ("kl=us-en",        f"https://duckduckgo.com/ac/?q={q}&type=list&kl=us-en"),
    ("kl=in-en",        f"https://duckduckgo.com/ac/?q={q}&type=list&kl=in-en"),
    ("kl=in-hi",        f"https://duckduckgo.com/ac/?q={q}&type=list&kl=in-hi"),
    ("kl=jp-jp",        f"https://duckduckgo.com/ac/?q={q}&type=list&kl=jp-jp"),
    ("kl=xx-xx (bogus)", f"https://duckduckgo.com/ac/?q={q}&type=list&kl=xx-yy"),
]

for name, url in tests:
    print(f"--- {name} ---")
    try:
        raw = get(url)
    except Exception as e:
        print(f"    FAILED: {e}\n")
        continue
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        print(f"    not JSON: {raw[:160]!r}\n")
        continue
    if isinstance(data, list) and data and isinstance(data[0], str):
        sug = data[1] if len(data) > 1 and isinstance(data[1], list) else []
        print(f'    list-form  query={data[0]!r}  n={len(sug)}')
        for s in sug[:6]:
            print(f"      - {s}")
    elif isinstance(data, list):
        print(f"    obj-form n={len(data)}")
        for d in data[:6]:
            if isinstance(d, dict):
                print(f"      - {d.get('phrase')}")
    else:
        print(f"    unexpected: {json.dumps(data)[:200]}")
    print()
