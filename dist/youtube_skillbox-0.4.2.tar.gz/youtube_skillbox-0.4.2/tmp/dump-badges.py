"""Dump the raw videoRenderer keys/fields from innertube search to locate the verified badge."""
import json
import sys

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

key, base_ctx = ytdata._innertube_cfg()
ctx = json.loads(json.dumps(base_ctx))
ctx.setdefault("client", {})["gl"] = "US"
ctx["client"]["hl"] = "en"

data = ytdata._innertube_post("search", {"context": ctx, "query": "mrbeast"})
renderers = list(ytdata._find_renderers(data, "videoRenderer"))
print(f"renderers found: {len(renderers)}\n")

for idx, v in enumerate(renderers[:3]):
    print(f"=== renderer {idx}: {v.get('videoId')} ===")
    print("top-level keys:", sorted(v.keys()))
    for k in ("badges", "ownerBadges", "ownerText", "shortBylineText", "longBylineText",
              "publishedTimeText", "viewCountText", "lengthText", "detailedMetadataSnippets"):
        if k in v:
            print(f"  {k}: {json.dumps(v[k], ensure_ascii=False)[:300]}")
    # any key anywhere containing 'badge' or 'verified' or 'style'
    def scan(o, p=""):
        if isinstance(o, dict):
            for k, val in o.items():
                if any(t in k.lower() for t in ("badge", "verified", "styletype")):
                    print(f"  HIT {p}.{k}: {json.dumps(val, ensure_ascii=False)[:200]}")
                scan(val, f"{p}.{k}")
        elif isinstance(o, list):
            for i, val in enumerate(o):
                scan(val, f"{p}[{i}]")
    scan(v)
    print()

# also check what yt-dlp does: is the badge maybe only on the 'videoRenderer' of a
# different surface (e.g. with params / different client)?
print("=== check: does the response carry any 'VERIFIED' string at all? ===")
blob = json.dumps(data)
print("contains VERIFIED:", "VERIFIED" in blob)
print("contains verified:", "verified" in blob.lower())
import re
for m in re.finditer(r'.{80}[Vv]erified.{80}', blob):
    print("  ...", m.group(0))
