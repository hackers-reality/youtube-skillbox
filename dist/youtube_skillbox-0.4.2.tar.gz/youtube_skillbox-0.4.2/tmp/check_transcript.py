import json, sys

with open(sys.argv[1], 'r', encoding='utf-8') as f:
    d = json.load(f)

print(f'Video: {d["video_id"]}')
print(f'Title: {d.get("metadata", {}).get("title", "N/A")}')
print(f'Languages available: {[t["language"] for t in d["transcripts"]]}')
for t in d["transcripts"]:
    print(f'  {t["language"]}: {len(t["transcript"])} segments')
print()
