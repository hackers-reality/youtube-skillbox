for r in rows:
        flags = ("  Y" if r["year_trend"] else "") + ("  Q" if r["question"] else "")
        print(f"{r['score']:>5}  {r['yt']:>3}  {r['ddg']:>3}  #{r['best_pos']:<3} "
              f"{r['keyword']}{flags}")


def _append_trend_log(seed, gl, hl, rows):
    """Append a keyword score snapshot to the trend log."""
    entry = {
        "seed": seed,
        "gl": gl,
        "hl": hl,
        "ts": time.strftime("%Y-%m-%d %H:%M"),
        "keywords": [{"k": r["keyword"], "s": r["score"],
                      "yt": r["yt"], "ddg": r["ddg"], "pos": r["best_pos"],
                      "Y": r["year_trend"], "Q": r["question"]}
                     for r in rows]
    }
    try:
        with open(_TREND_LOG, encoding="utf-8") as f:
            log = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        log = []
    log.append(entry)
    # keep last 500 entries per seed/gl/hl to bound file size
    key = (seed, gl, hl)
    log = [e for e in log if (e["seed"], e["gl"], e["hl"]) != key][-499:] + [entry]
    with open(_TREND_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, ensure_ascii=False, indent=2)


def cmd_trends(a):
    """Show historical trend for a seed keyword from the trend log."""
    try:
        with open(_TREND_LOG, encoding="utf-8") as f:
            log = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print("ERROR: no trend data yet — run `keywords` a few times first", file=sys.stderr)
        sys.exit(1)

    entries = [e for e in log
               if e["seed"].lower() == a.seed.lower()
               and e["gl"].upper() == a.gl.upper()
               and e["hl"].lower() == a.hl.lower()]
    if not entries:
        print(f"ERROR: no trend data for seed={a.seed!r} gl={a.gl} hl={a.hl}", file=sys.stderr)
        sys.exit(1)

    # filter by days
    if a.days:
        cutoff = time.time() - a.days * 86400
        entries = [e for e in entries
                   if time.mktime(time.strptime(e["ts"], "%Y-%m-%d %H:%M")) >= cutoff]

    if not entries:
        print("No entries in the selected window.")
        return

    # collect all keywords ever seen for this seed
    all_kw = {}
    for e in entries:
        for kw in e["keywords"]:
            all_kw.setdefault(kw["k"], []).append((e["ts"], kw["s"], kw["yt"], kw["ddg"], kw["pos"], kw["Y"], kw["Q"]))

    if a.json:
        print(json.dumps({"seed": a.seed, "gl": a.gl, "hl": a.hl,
                          "window_days": a.days, "keywords": all_kw},
                         ensure_ascii=False, indent=2))
        return

    print(f'Trend for "{a.seed}"  (gl={a.gl} hl={a.hl}'
          f'{", last " + str(a.days) + " days" if a.days else ""}) — {len(entries)} snapshots\n')

    # show top 20 by latest score
    latest = entries[-1]
    latest_scores = {kw["k"]: kw["s"] for kw in latest["keywords"]}
    top_kw = sorted(latest_scores.items(), key=lambda x: -x[1])[: a.limit]

    for kw, score in top_kw:
        hist = all_kw[kw]
        scores = [h[1] for h in hist]
        delta = scores[-1] - scores[0] if len(scores) > 1 else 0
        vel = scores[-1] - scores[-2] if len(scores) > 1 else 0
        trend = "↑" if vel > 5 else ("↓" if vel < -5 else "→")
        spark = "".join("█" * min(8, max(1, s // 10)) for s in scores[-8:])
        first_ts, last_ts = hist[0][0], hist[-1][0]
        print(f"  {score:>3}  {trend}  {spark}  {kw}")
        if a.verbose:
            print(f"       {len(hist)} pts  {first_ts} -> {last_ts}  Delta={delta:+d}  vel={vel:+d}")

    if a.verbose:
        print(f"\nAll {len(all_kw)} keywords tracked. Use --limit to see more.")


# ---- Rank tracking: where a video sits for a keyword (no API key) ----