with open("skills/youtube/scripts/ytdata.py", "r", encoding="utf-8") as f:
    lines = f.readlines()

# Find the audit subparser block (lines 1998-2007, 0-indexed: 1997-2006)
start = None
for i, line in enumerate(lines):
    if 'p = sub.add_parser("audit"' in line:
        start = i
        break

if start is None:
    print("audit subparser not found")
else:
    # Find the end - the next p.add_parser or a = ap.parse_args()
    end = None
    for i in range(start + 1, len(lines)):
        if 'p.add_parser(' in lines[i] or 'a = ap.parse_args()' in lines[i]:
            end = i
            break
    
    if end is None:
        print("Could not find end of audit subparser block")
    else:
        print(f"Removing lines {start+1} through {end}")
        new_lines = lines[:start] + lines[end:]
        with open("skills/youtube/scripts/ytdata.py", "w", encoding="utf-8") as f:
            f.writelines(new_lines)
        print(f"New file has {len(new_lines)} lines")
