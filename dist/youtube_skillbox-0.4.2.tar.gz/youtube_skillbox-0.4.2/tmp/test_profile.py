import urllib.request
import re
import json

url = 'https://www.youtube.com/channel/UC7YGYCm-n48Xea43wEqUDRg'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'replace')

# Extract ytInitialData
for pat in (r'var ytInitialData\s*=\s*(\{.*?\});</script>',
            r'window\["ytInitialData"\]\s*=\s*(\{.*?\});',
            r'ytInitialData\s*=\s*(\{.*?\});'):
    m = re.search(pat, html, re.S)
    if m:
        data = json.loads(m.group(1))
        print('Found ytInitialData')
        break

# Find channel metadata
def find_channel(obj, path=''):
    if isinstance(obj, dict):
        if 'channelMetadataRenderer' in obj:
            return obj
        for k, v in obj.items():
            r = find_channel(v, f'{path}.{k}')
            if r:
                return r
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            r = find_channel(v, f'{path}[{i}]')
            if r:
                return r
    return None

chan = find_channel(data)
if chan:
    meta = chan.get('channelMetadataRenderer', {})
    print('Title:', meta.get('title'))
    print('Subscribers:', meta.get('subscriberCount'))
    print('Description:', meta.get('description'))
else:
    print('Not found in ytInitialData')
    # Try to find in other places
    def find_any(obj, key):
        if isinstance(obj, dict):
            if key in obj:
                return obj[key]
            for v in obj.values():
                r = find_any(v, key)
                if r:
                    return r
        elif isinstance(obj, list):
            for v in obj:
                r = find_any(v, key)
                if r:
                    return r
        return None
    
    sub = find_any(data, 'subscriberCount')
    if sub:
        print('Found subscriberCount:', sub)