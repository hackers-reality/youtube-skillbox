"""Quality gates for _parse_age (using formats probed live from YouTube) + verified badge."""
import sys

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

print("=== _parse_age (formats verified against live search output) ===")
# (input, expected days) -- 'mo' is what YouTube actually emits for months
cases = [
    ("1d ago", 1), ("2w ago", 14), ("4w ago", 28),
    ("1mo ago", 30), ("3mo ago", 90), ("11mo ago", 330),
    ("1y ago", 365), ("5y ago", 1825), ("17y ago", 6205),
    ("3 months ago", 90), ("1 year ago", 365),
    ("16 hours ago", 0),
    ("just now", None), ("Premiering tomorrow", None),
    ("Streamed 3 days ago", None), ("", None), (None, None),
    ("5m ago", None),      # 'm' alone is never emitted; don't guess
    ("no idea", None),
]
fails = 0
for txt, want in cases:
    got = ytdata._parse_age(txt)
    if got != want:
        fails += 1
        print(f"  FAIL {txt!r:26} -> {got}  (want {want})")
print(f"  {len(cases) - fails}/{len(cases)} passed")

print("\n=== verified badge (positive: MrBeast) ===")
res = ytdata._innertube_search("mrbeast", 3, gl="US", hl="en")
for r in res:
    print(f"  {r['channel']!r:20} verified={r['channel_is_verified']}  age={r['age_days']}d")
if not all(r["channel_is_verified"] for r in res):
    fails += 1
    print("  FAIL: MrBeast results must all be verified")

print("\n=== unverified channel -> None (never False) ===")
res2 = ytdata._innertube_search("how to make paneer", 6, gl="US", hl="en")
ver = [r["channel_is_verified"] for r in res2]
print(f"  flags: {ver}")
if any(v is False for v in ver):
    fails += 1
    print("  FAIL: must be True/None, never False")

print("\n=== slim() passthrough ===")
s = ytdata.slim({"id": "x", "title": "t", "channel": "c"})
print(f"  age_days on plain entry: {s.get('age_days')}")
if s.get("age_days") is not None:
    fails += 1
    print("  FAIL: should be None for entries without age")

print("\nRESULT:", "ALL PASS" if fails == 0 else f"{fails} FAILURES")
sys.exit(1 if fails else 0)
