import subprocess
import json
import sys

video_ids = [
    "Y8jiSfWz0AE",
    "kp5tuB99ByQ",
    "-uE4WxFX5XY",
    "2J7_e6hOlnM",
    "DO208RplSd8",
    "2K5LX66RwYA",
    "LP1s9K8GddY",
]

results = []

for vid in video_ids:
    print(f"Fetching transcript for {vid}...", flush=True)
    result = subprocess.run(
        [sys.executable, "skills/transcript/scripts/gettranscript.py", vid, "--format", "json", "--all-langs"],
        capture_output=True,
        text=True,
        cwd="E:/youtube-skillbox"
    )
    
    if result.returncode != 0:
        print(f"  FAILED: {result.stderr.strip()[:200]}")
        results.append({"video_id": vid, "error": result.stderr.strip()[:200]})
        continue
    
    try:
        data = json.loads(result.stdout)
        langs = [t["language"] for t in data.get("transcripts", [])]
        total_segments = sum(len(t["transcript"]) for t in data.get("transcripts", []))
        print(f"  OK: {len(langs)} languages, {total_segments} segments")
        for t in data.get("transcripts", []):
            print(f"    - {t['language']}: {len(t['transcript'])} segments")
        results.append({"video_id": vid, "transcripts": data["transcripts"], "metadata": data.get("metadata", {})})
    except Exception as e:
        print(f"  PARSE ERROR: {e}")
        results.append({"video_id": vid, "error": str(e)})

print("\n" + "="*60)
print("SUMMARY:")
for r in results:
    if "transcripts" in r:
        langs = [t["language"] for t in r["transcripts"]]
        total = sum(len(t["transcript"]) for t in r["transcripts"])
        print(f"  {r['video_id']}: {len(langs)} langs, {total} segments")
    else:
        print(f"  {r['video_id']}: FAILED - {r.get('error', 'unknown')}")
