with open('skills/youtube/scripts/ytdata.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

in_outliers = False
for i, line in enumerate(lines):
    if 'add_parser("outliers"' in line:
        in_outliers = True
    if in_outliers:
        print(f'{i+1}: {line.rstrip()}')
    if in_outliers and 'set_defaults(func=cmd_outliers)' in line:
        break