with open('skills/yt-workflow/scripts/run_workflow.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix sys[2] back to sys.stderr
content = content.replace('sys[2]', 'sys.stderr')

with open('skills/yt-workflow/scripts/run_workflow.py', 'w', encoding='utf-8') as f:
    f.write(content)

print('sys.stderr count:', content.count('sys.stderr'))
print('sys[2] count:', content.count('sys[2]'))
print('Done fixing sys.stderr')
