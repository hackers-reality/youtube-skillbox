import re

with open('assets/banner.svg', 'r', encoding='utf-8') as f:
    content = f.read()

print(f"SVG file size: {len(content)} characters")
print()

# Check for subcommand names
subcommands = ['search', 'keywords', 'compete', 'trends', 'track', 'scorecard', 
               'outliers', 'gap', 'profile', 'sections', 'channel', 'latest', 
               'posts', 'home', 'shows', 'playlist', 'info']

print("Subcommands found in SVG:")
for sc in subcommands:
    if sc in content:
        print(f"  [OK] {sc}")
    else:
        print(f"  [MISSING] {sc}")

# Check for any outdated references
print()
print("Checking for outdated references:")
old_terms = ['rank', 'viral', 'sections', 'channel', 'latest']
for ot in old_terms:
    if ot in content:
        print(f"  Found '{ot}' in SVG")