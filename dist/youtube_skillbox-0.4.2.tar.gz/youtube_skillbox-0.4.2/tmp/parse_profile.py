import sys, json

data = {}
for line in sys.stdin:
    line = line.strip()
    if not line or not line.startswith('{'):
        continue
    try:
        d = json.loads(line)
        if 'channel_follower_count' in d and d['channel_follower_count']:
            data['subs'] = d['channel_follower_count']
            data['channel'] = d.get('channel', d.get('uploader'))
            data['desc'] = d.get('description', d.get('channel_description', ''))[:200]
            break
    except:
        pass

print('Channel:', data.get('channel'))
print('Subscribers:', data.get('subs'))
print('Description:', data.get('desc'))