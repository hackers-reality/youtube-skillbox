"""Dump videoRenderer keys to find where view counts live."""
import json
import sys

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

key, ctx = ytdata._innertube_cfg()
ctx = json.loads(json.dumps(ctx))
ctx.setdefault("client", {})["gl"] = "US"
ctx["client"]["hl"] = "en"
data = ytdata._innertube_post("search", {"context": ctx, "query": "how to grow youtube",
                                         "params": ytdata._YT_SEARCH_PARAMS})

v = next(ytdata._find_renderers(data, "videoRenderer"))
print("videoRenderer keys:")
print(sorted(v.keys()))
print()
for k in sorted(v.keys()):
    if "view" in k.lower() or "count" in k.lower() or "short" in k.lower():
        print(f"  {k} = {json.dumps(v[k], ensure_ascii=False)[:300]}")
print()
print("_parse_count tests:")
for t in ("1,234,567 views", "1.2M views", "No views", "48K views", None, ""):
    print(f"  {t!r:25} -> {ytdata._parse_count(t)}")
print()
parsed = ytdata._parse_video(v)
print("parsed item:", json.dumps(parsed, ensure_ascii=False, indent=2))
