import urllib.request
import re
import json

url = 'https://www.youtube.com/channel/UC7YGYCm-n48Xea43wEqUDRg'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
html = urllib.request.urlopen(req, timeout=30).read().decode('utf-8', 'replace')

# Extract ytcfg
m = re.search(r'ytcfg\.set\((\{.*?\})\);', html, re.S)
if m:
    cfg = json.loads(m.group(1))
    key = cfg.get('INNERTUBE_API_KEY')
    ctx = cfg.get('INNERTUBE_CONTEXT')
    print('API Key:', key[:20] + '...' if key else None)
    print('Context:', 'yes' if ctx else 'no')

# Extract continuation token for the channel page
# The channel page has a browse endpoint
# Let's try to call the browse endpoint directly
if key and ctx:
    # Get the browse ID from the URL
    browse_id = 'UC7YGYCm-n48Xea43wEqUDRg'
    
    payload = json.dumps({"context": ctx, "browseId": browse_id}).encode('utf-8')
    api_url = f"https://www.youtube.com/youtubei/v1/browse?key={key}"
    headers = {'User-Agent': 'Mozilla/5.0', 'Content-Type': 'application/json'}
    req2 = urllib.request.Request(api_url, data=payload, headers=headers, method='POST')
    resp = json.loads(urllib.request.urlopen(req2, timeout=30).read().decode('utf-8', 'replace'))
    
    # Search for subscriber count in response
    def find_all(obj, key, path=''):
        if isinstance(obj, dict):
            if key in obj:
                print(f'Found {key} at {path}: {obj[key]}')
            for k, v in obj.items():
                find_all(v, key, f'{path}.{k}')
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                find_all(v, key, f'{path}[{i}]')
    
    find_all(resp, 'subscriberCount')
    find_all(resp, 'channel_follower_count')
    find_all(resp, 'channelFollowerCount')