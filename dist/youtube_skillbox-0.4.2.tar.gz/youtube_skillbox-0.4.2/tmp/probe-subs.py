"""Probe: does the innertube search SERP carry subscriber counts? (Gemini Metric B1)

Gemini's idea: a video with 500K views on a 2K-sub channel means the KEYWORD
drives the traffic (low competition / high velocity). Every top video from a
5M+ sub channel means a massive barrier. Either way we need subs per result.
"""
import json
import re
import sys

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

key, base = ytdata._innertube_cfg()
ctx = json.loads(json.dumps(base))
ctx.setdefault("client", {})["gl"] = "US"
ctx["client"]["hl"] = "en"

data = ytdata._innertube_post("search", {"context": ctx, "query": "how to make paneer at home"})
renderers = list(ytdata._find_renderers(data, "videoRenderer"))
print(f"renderers: {len(renderers)}\n")

# 1. where might subscriber counts live?
print("=== keys present on a videoRenderer ===")
print(sorted(renderers[0].keys()))

print("\n=== scan for subscriber-ish strings anywhere ===")
blob = json.dumps(data)
for pat in (r"subscriber", r"subscribers", r"\d+\.?\d*[MK]? subscribers"):
    hits = re.findall(pat, blob, re.I)
    print(f"  {pat!r}: {len(hits)} hits, e.g. {hits[:3]}")

print("\n=== the accessibility label Gemini-style parsing would use ===")
for i, v in enumerate(renderers[:5]):
    # hunt recursively for a label mentioning subscribers
    found = []

    def scan(o, p=""):
        if isinstance(o, dict):
            for k, val in o.items():
                if isinstance(val, str) and "subscriber" in val.lower():
                    found.append((f"{p}.{k}", val))
                scan(val, f"{p}.{k}")
        elif isinstance(o, list):
            for j, val in enumerate(o):
                scan(val, f"{p}[{j}]")

    scan(v)
    title = ytdata._runs_text(v.get("title"))[:40]
    print(f"  [{i}] {title!r}")
    for p, s in found[:2]:
        print(f"       {p}: {s[:110]}")
    if not found:
        print("       (no subscriber string on this renderer)")

# 2. does the *channel* renderer / ownerText carry a subscriber run?
print("\n=== ownerText / shortBylineText raw runs ===")
v = renderers[0]
for k in ("ownerText", "shortBylineText", "longBylineText"):
    if k in v:
        print(f"  {k}: {json.dumps(v[k], ensure_ascii=False)[:400]}")

# 3. is there a separate 'channelRenderer' with subscriberCountText?
print("\n=== channelRenderer present? ===")
ch = list(ytdata._find_renderers(data, "channelRenderer"))
print(f"  channelRenderer count: {len(ch)}")
if ch:
    print("  keys:", sorted(ch[0].keys()))
    for k in ch[0]:
        if "sub" in k.lower() or "count" in k.lower():
            print(f"    {k}: {json.dumps(ch[0][k], ensure_ascii=False)[:200]}")

# 4. videoRenderer: any field with 'subscriber' in its NAME?
print("\n=== field names anywhere under a videoRenderer containing sub/count/owner ===")
def names(o, acc):
    if isinstance(o, dict):
        for k, val in o.items():
            if re.search(r"sub|count|owner|byline", k, re.I):
                acc.add(k)
            names(val, acc)
    elif isinstance(o, list):
        for val in o:
            names(val, acc)
acc = set()
names(renderers[0], acc)
print(" ", sorted(acc))
