with open('skills/yt-workflow/scripts/run_workflow.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Replace .stdout with [1] and .stderr with [2] for tuple unpacking
content = content.replace('.stdout', '[1]')
content = content.replace('.stderr', '[2]')

with open('skills/yt-workflow/scripts/run_workflow.py', 'w', encoding='utf-8') as f:
    f.write(content)

print(f'.stdout count: {content.count(".stdout")}')
print(f'.stderr count: {content.count(".stderr")}')
print(f'.returncode count: {content.count(".returncode")}')