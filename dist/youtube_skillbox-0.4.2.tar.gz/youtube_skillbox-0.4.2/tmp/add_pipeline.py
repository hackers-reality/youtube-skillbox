import os

skills = {
    "yt-script": {
        "position": "Phase 3 — Hook Analysis",
        "inputs": "Transcripts from transcript skill (Phase 2)",
        "outputs": "Hook scores (0-100) per video → feeds yt-package, yt-audit",
        "triggers": "write script, hook ideas, opening line, first 15 seconds"
    },
    "yt-package": {
        "position": "Phase 4 — Title/Thumbnail Audit",
        "inputs": "Channel titles from youtube skill; hook scores from yt-script",
        "outputs": "Title scores, thumbnail briefs → feeds yt-seo, yt-audit",
        "triggers": "title ideas, thumbnail text, packaging, CTR is bad"
    },
    "yt-seo": {
        "position": "Phase 5 — SEO / Keyword / Competition Audit",
        "inputs": "Keywords from youtube skill; target video from user",
        "outputs": "Keywords, competition scores, scorecards → feeds yt-audit, yt-plan",
        "triggers": "write description, tags, SEO, help this video get found"
    },
    "yt-viral": {
        "position": "Phase 6 — Outlier / Competitor Analysis",
        "inputs": "Channel handle from user; niche from yt-seo",
        "outputs": "Outliers (views/subs ratio), competitor analysis → feeds yt-audit, yt-plan",
        "triggers": "what's working in niche, find viral videos, why did this blow up"
    },
    "yt-retention": {
        "position": "Phase 7 — Retention Analysis (optional)",
        "inputs": "YouTube Studio retention CSV export from user",
        "outputs": "Drop-off points, retention curves → feeds yt-audit, yt-script",
        "triggers": "why do people stop watching, retention is bad, fix my pacing"
    },
    "yt-audit": {
        "position": "Phase 8 — Final Synthesis (ONE fix)",
        "inputs": "ALL previous phases: youtube, transcript, yt-script, yt-package, yt-seo, yt-viral, yt-retention",
        "outputs": "Single biggest fix, 3 working things, what NOT to do → final deliverable",
        "triggers": "audit my channel, why isn't this growing, review my videos"
    },
    "yt-plan": {
        "position": "Post-Audit — Content Planning",
        "inputs": "Audit output (yt-audit) + keywords (yt-seo) + outliers (yt-viral)",
        "outputs": "Weekly/monthly content calendar → feeds yt-script, yt-package",
        "triggers": "plan my week, content calendar, what should I post"
    },
    "yt-chapters": {
        "position": "Post-Production — Chapters from Transcript",
        "inputs": "Transcript from transcript skill",
        "outputs": "Validated YouTube chapters → feeds yt-package (packaging)",
        "triggers": "add chapters, timestamps, break this video into sections"
    },
    "yt-shorts": {
        "position": "Post-Production — Shorts from Long-form",
        "inputs": "Transcript from transcript skill",
        "outputs": "Self-contained Shorts scripts → feeds yt-package, yt-plan",
        "triggers": "cut this into shorts, clip this, repurpose this video"
    },
    "yt-edit": {
        "position": "Post-Production — Edit Decision List",
        "inputs": "Transcript from transcript skill",
        "outputs": "Edit decision list (dead air, fillers, retakes) → feeds production",
        "triggers": "edit this, cut dead space, tighten this video"
    },
    "yt-comment": {
        "position": "Post-Publish — Community Management",
        "inputs": "Channel handle + comment threads from youtube skill",
        "outputs": "Draft replies in creator voice → feeds community management",
        "triggers": "reply to comments, handle comment section"
    },
}

for skill_dir, meta in skills.items():
    path = f"E:/youtube-skillbox/skills/{skill_dir}/SKILL.md"
    if not os.path.exists(path):
        print(f"Missing: {skill_dir}")
        continue
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    if 'Pipeline Position' not in content:
        # Insert after frontmatter
        pipeline_text = f"""**Pipeline Position:** {meta['position']}
**Inputs:** {meta['inputs']}
**Outputs:** {meta['outputs']}
**Triggers:** {meta['triggers']}

"""
        # Insert after the first --- ... --- block (frontmatter)
        parts = content.split('---', 2)
        if len(parts) >= 3:
            content = parts[0] + '---' + parts[1] + '---' + pipeline_text + parts[2]
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f"Updated: {skill_dir}")
        else:
            print(f"Could not parse frontmatter: {skill_dir}")
    else:
        print(f"Already has pipeline: {skill_dir}")

print("Done!")