"""Prove the yt-dlp fallback fires when the Innertube endpoint is unavailable."""
import sys
import types

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata


def boom():
    raise RuntimeError("simulated innertube outage")


ytdata._innertube_cfg = boom
a = types.SimpleNamespace(query="rick astley", limit=3, gl="US", hl="en", json=False)
print("--- cmd_search with innertube forced to fail ---")
ytdata.cmd_search(a)
print("\n--- cmd_track with innertube forced to fail ---")
b = types.SimpleNamespace(query="never gonna give you up", top=3, video="dQw4w9WgXcQ",
                          gl="US", hl="en", log="~/.ytdata-ranklog.json", json=False)
ytdata.cmd_track(b)
