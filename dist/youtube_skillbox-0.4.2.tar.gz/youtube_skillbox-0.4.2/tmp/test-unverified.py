"""Negative case: find genuinely unverified channels so verified=None is proven, not assumed."""
import sys

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

unverified = verified = 0
for q in ("my first video test upload", "random vlog 2026",
          "homemade recipe village kitchen", "kids drawing time lapse"):
    try:
        for r in ytdata._innertube_search(q, 6, gl="US", hl="en"):
            flag = r["channel_is_verified"]
            if flag:
                verified += 1
            else:
                unverified += 1
            print(f"  {q[:26]:28} {str(r['channel'])[:26]:28} verified={flag}")
    except Exception as e:
        print(f"  {q}: ERR {e}")

print(f"\nverified={verified}  unverified={unverified}")
if unverified == 0:
    print("RESULT: negative case NOT exercised (every hit was verified)")
    sys.exit(2)
if verified == 0:
    print("RESULT: positive case NOT exercised")
    sys.exit(2)
print("RESULT: BOTH CASES EXERCISED — True and None both observed")
