"""Edge case tests for compete + track competition summary."""
import sys
import types

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

print("=== 1. Empty SERP (should fail loud) ===")
# monkey-patch to return empty
ytdata._innertube_search = lambda *a, **k: []
a = types.SimpleNamespace(query="asdfghjkl_nonexistent_query_xyz", top=10,
                          gl="US", hl="en", json=False, video=None, log="~/.ytdata-ranklog.json")
try:
    ytdata.cmd_track(a)
    print("  FAIL: should error")
except SystemExit as e:
    print(f"  OK: SystemExit({e.code})")

print("\n=== 2. yt-dlp fallback path (no age_days) ===")
# force innertube to fail, fall back to yt-dlp
ytdata._innertube_search = lambda *a, **k: (_ for _ in ()).throw(Exception("simulated fail"))
a = types.SimpleNamespace(query="python tutorial", top=5, gl="US", hl="en",
                          json=False, video=None, log="~/.ytdata-ranklog.json")
ytdata.cmd_track(a)

print("\n=== 3. JSON output (compete) ===")
# restore innertube
import importlib
importlib.reload(ytdata)
a = types.SimpleNamespace(query="mrbeast", top=3, gl="US", hl="en", json=True)
ytdata.cmd_compete(a)

print("\n=== 4. JSON output (track with competition) ===")
a = types.SimpleNamespace(query="python tutorial", top=3, gl="US", hl="en",
                          json=True, video="dQw4w9WgXcQ", log="~/.ytdata-ranklog.json")
ytdata.cmd_track(a)

print("\n=== 5. Single-word informational query (not brand) ===")
a = types.SimpleNamespace(query="python", top=5, gl="US", hl="en", json=False)
ytdata.cmd_compete(a)

print("\n=== 6. Two-word brand-like query ===")
a = types.SimpleNamespace(query="google maps", top=5, gl="US", hl="en", json=False)
ytdata.cmd_compete(a)