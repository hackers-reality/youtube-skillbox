"""Probe the real publishedTimeText formats YouTube emits across video ages."""
import sys

sys.path.insert(0, r"E:\youtube-skillbox\skills\youtube\scripts")
import ytdata

for stream in (sys.stdout, sys.stderr):
    try:
        stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

seen = {}
for q in ("mrbeast", "python tutorial", "star wars", "moon landing 1969",
          "how to cook rice", "minecraft let's play", "old commercial 1980s"):
    try:
        items = ytdata._innertube_search(q, 10, gl="US", hl="en")
    except Exception as e:
        print(f"  {q}: FAILED {e}")
        continue
    for it in items:
        raw = it.get("age_days")
        # re-fetch the raw text to record the literal string
        pass
    # re-run at raw level to get literal strings
    key, base = ytdata._innertube_cfg()
    import json
    ctx = json.loads(json.dumps(base))
    ctx.setdefault("client", {})["gl"] = "US"
    ctx["client"]["hl"] = "en"
    data = ytdata._innertube_post("search", {"context": ctx, "query": q})
    for v in ytdata._find_renderers(data, "videoRenderer"):
        node = v.get("publishedTimeText") or {}
        txt = node.get("simpleText") or ytdata._runs_text(node)
        if txt:
            seen.setdefault(txt, ytdata._parse_age(txt))

print("=== literal publishedTimeText -> parsed age_days ===")
for txt, age in sorted(seen.items(), key=lambda kv: (kv[1] is None, kv[1] or 0)):
    print(f"  {txt!r:24} -> {age}")

# format classes seen
import re
classes = set()
for t in seen:
    m = re.match(r"\s*\d+\s*([a-zA-Z]+)", t)
    classes.add(m.group(1).lower() if m else t)
print("\nunit words seen:", sorted(classes))
