import json

with open('tmp/browse_resp.json', 'r', encoding='utf-8') as f:
    resp = json.load(f)

# Check header content
header = resp.get('header', {})
page_header = header.get('pageHeaderRenderer', {})
content = page_header.get('content', {})
print('Content keys:', list(content.keys()))

# The content might have pageHeaderViewModel or similar
def find_all(obj, key, path=''):
    if isinstance(obj, dict):
        if key in obj:
            print(f'Found {key} at {path}: {obj[key]}')
        for k, v in obj.items():
            find_all(v, key, f'{path}.{k}')
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            find_all(v, key, f'{path}[{i}]')

find_all(content, 'subscriber')
find_all(content, 'follower')

# Also check the full pageHeaderRenderer
find_all(page_header, 'subscriber')
find_all(page_header, 'follower')