"""
YouTube Skillbox package.
"""

__version__ = "0.4.2"